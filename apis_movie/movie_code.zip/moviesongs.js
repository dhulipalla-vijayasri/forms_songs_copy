var Movie_songs = [
    {
        image: "poster1.jpg",
        Audio: "Emito Idhi.mp3",
        title: "Rang De",
        text: " The film grossed ₹19.6 crore worldwide in its first weekend.",   //0
        date: "26 March 2021",
        music: "Devi sri Prasad"
    },
    {
        image: "poster.jpg",
        Audio: "Kannulu Neevi.mp3",
        title: "Sakhi",
        text: "Indian Tamil-language film written and directed by Mani Ratnam",   //1
        date: "14 April 2000",
        music: "A. R. Rahman"
    },
    {
        image: "poster3.jpg",
        Audio: "Chiguraku Chaatu.mp3",
        title: "Gudumba shankar",
        text: " Telugu-language action comedy film directed by Veera Shankar Bairisetty.",   //2
        date: "10 September 2004",
        music: "Devi sri Prasad"
    },
    {
        image: "poster4.jpg",
        Audio: "Varsincha Megamla.mp3",
        title: "Cheli ",
        text: "Indian Tamil-language romance film directed by Gautham Menon. ",   //3
        date: "2 February 2001",
        music: " Harris Jayaraj "
    },
    {
        image: "poster5.jpg",
        Audio: "Tharagathi Gadhi.mp3",
        title: "Colour Photo",
        text: "Telugu movie <br> Imdb Rating 8.5 / 10",   //4
        date: "Read More",
        music: "Kaala Bhairava"
    },
    {
        image: "poster1.jpg",
        Audio: "Emito Idhi.mp3",
        title: "Rang De",
        text: " The film grossed ₹19.6 crore worldwide in its first weekend.",   //5
        date: "26 March 2021",
        music: "Devi sri Prasad"
    },
    {
        image: "poster.jpg",
        Audio: "Kannulu Neevi.mp3",
        title: "Sakhi",
        text: "Indian Tamil-language film written and directed by Mani Ratnam",   //6
        date: "14 April 2000",
        music: "A. R. Rahman"
    },
    {
        image: "poster3.jpg",
        Audio: "Chiguraku Chaatu.mp3",
        title: "Gudumba shankar",
        text: " Telugu-language action comedy film directed by Veera Shankar Bairisetty.",   //7
        date: "10 September 2004",
        music: "Devi sri Prasad"
    },
    {
        image: "poster4.jpg",
        Audio: "Varsincha Megamla.mp3",
        title: "Cheli ",
        text: "Indian Tamil-language romance film directed by Gautham Menon. ",   //8
        date: "2 February 2001",
        music: " Harris Jayaraj "
    },
    {
        image: "poster5.jpg",
        Audio: "Tharagathi Gadhi.mp3",
        title: "Colour Photo",
        text: " Telugu movie <br> Imdb Rating 8.5 / 10",   //9
        date: "Read More",
        music: "Kaala Bhairava"
    },
    {
        image: "poster1.jpg",
        Audio: "Emito Idhi.mp3",
        title: "Rang De",
        text: " The film grossed ₹19.6 crore worldwide in its first weekend.",   //10
        date: "26 March 2021",
        music: "Devi sri Prasad"
    },
    {
        image: "poster.jpg",
        Audio: "Kannulu Neevi.mp3",
        title: "Sakhi",
        text: "Indian Tamil-language film written and directed by Mani Ratnam",   //11
        date: "14 April 2000",
        music: "A. R. Rahman"
    },
    {
        image: "poster3.jpg",
        Audio: "Chiguraku Chaatu.mp3",
        title: "Gudumba shankar",
        text: " Telugu-language action comedy film directed by Veera Shankar Bairisetty.",   //12
        date: "10 September 2004",
        music: "Devi sri Prasad"
    },
    {
        image: "poster4.jpg",
        Audio: "Varsincha Megamla.mp3",
        title: "Cheli ",
        text: "Indian Tamil-language romance film directed by Gautham Menon. ",   //13
        date: "2 February 2001",
        music: " Harris Jayaraj "
    },
    {
        image: "poster5.jpg",
        Audio: "Tharagathi Gadhi.mp3",
        title: "Colour Photo",
        text: "Telugu movie <br> Imdb Rating 8.5 / 10",   //14
        date: "Read More",
        music: "Kaala Bhairava"
    },
    {
        image: "poster1.jpg",
        Audio: "Emito Idhi.mp3",
        title: "Rang De",
        text: " The film grossed ₹19.6 crore worldwide in its first weekend.",   //15
        date: "26 March 2021",
        music: "Devi sri Prasad"
    },
    {
        image: "poster.jpg",
        Audio: "Kannulu Neevi.mp3",
        title: "Sakhi",
        text: "Indian Tamil-language film written and directed by Mani Ratnam",   //16
        date: "14 April 2000",
        music: "A. R. Rahman"
    },
    {
        image: "poster3.jpg",
        Audio: "Chiguraku Chaatu.mp3",
        title: "Gudumba shankar",
        text: " Telugu-language action comedy film directed by Veera Shankar Bairisetty.",   //17
        date: "10 September 2004",
        music: "Devi sri Prasad"
    },
    {
        image: "poster4.jpg",
        Audio: "Varsincha Megamla.mp3",
        title: "Cheli ",
        text: "Indian Tamil-language romance film directed by Gautham Menon. ",   //18
        date: "2 February 2001",
        music: " Harris Jayaraj "
    },
    {
        image: "poster5.jpg",
        Audio: "Tharagathi Gadhi.mp3",
        title: "Colour Photo",
        text: "Telugu movie <br> Imdb Rating 8.5 / 10",   //0
        date: "Read More",
        music: "Kaala Bhairava"
    },
]